# Script 目录

这里存放一些其他文件。不知用途的情况下请勿擅自使用。

---

## 归档文件夹

`archived/` 文件夹包含已弃用的脚本文件，保留用于历史参考。详情请查看 [archived/README.md](archived/README.md)。
