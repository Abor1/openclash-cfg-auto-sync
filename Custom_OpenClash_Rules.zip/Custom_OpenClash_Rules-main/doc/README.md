<h1 align="center">
  📚 Documentation Assets
</h1>

<p align="center"><b>🖼️ 项目文档素材库 🖼️</b></p>

这里存放 Wiki 文档和 Readme 中使用的图片资源及补充文档。

---

## 📂 目录结构

| 目录 | 描述 |
| :--- | :--- |
| **`ipv6/`** | 🌐 IPv6 设置相关的图文素材 (涵盖 LEDE / OpenWrt)。 |
| **`openclash/`** | 🐙 OpenClash 插件设置相关的截图。 |
| **`openwrt/`** | 🐧 OpenWrt 通用设置或系统相关的图片。 |
| **`subconverter/`** | 🔄 订阅转换 (Subconverter) 相关的说明图片。 |

> [!NOTE]
> 此文件夹主要作为 **Wiki 的图床** 使用，直接阅读可能有缺失上下文。
> 完整文档请访问项目 [Wiki页面](https://github.com/Aethersailor/Custom_OpenClash_Rules/wiki)。
