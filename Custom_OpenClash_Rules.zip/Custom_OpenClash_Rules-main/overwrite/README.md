## 订阅转换模板  
这里存放供 OpenClash 覆写功能调用的远程配置文件
```
https://testingcf.jsdelivr.net/gh/Aethersailor/Custom_OpenClash_Rules@refs/heads/main/overwrite/Custom_Overwrite.yaml
```