## 订阅转换模板  
这里存放本项目的订阅转换模板，如果文件不存在则为尚未创建或因某些原因删除。  
  
| 名称 | 内容 |
|:-:|:-:|
| Custom_Clash.ini | 搭配 OpenClash 绕过大陆功能使用的模板 |
| Custom_Clash_Mainland.ini | 添加了 GitHub 反代地址的模板，适合架设在中国大陆地区的订阅转换服务使用 |
| Custom_Clash_GFW.ini | 仅包含国内直连和 GFW 规则的模板 |
| Custom_Clash_Lite.ini | 仅包含国内直连规则的模板，国外全部代理且不做分流 |
| Custom_Clash_Test.ini | 测试用订阅转换模板，请勿使用 |
