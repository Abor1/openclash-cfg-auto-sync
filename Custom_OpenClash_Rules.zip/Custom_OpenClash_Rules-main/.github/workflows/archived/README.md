# 归档的 GitHub Workflows

本文件夹包含已弃用但保留用于历史参考的 GitHub Actions 工作流文件。

## 文件说明

| 文件名 | 说明 | 弃用原因 |
| :--- | :--- | :--- |
| `generate_smart.yml` | 生成 Smart 分流规则配置 | OpenClash 已更新 Smart 覆写功能，此工作流已无必要 |
| `generate_smart_gfw.yml` | 生成 Smart GFW 规则配置 | OpenClash 已更新 Smart 覆写功能，此工作流已无必要 |

> **注意**: 这些工作流已停用，不会被 GitHub Actions 自动执行。如需使用，请将文件移回上级目录。
