# 🐍 Python Scripts

## 🛠️ 项目辅助与维护脚本 🛠️

这里存放项目使用的 Python 维护脚本（如规则处理、文件合并等）。

> [!CAUTION]
> **非开发人员请勿随意运行此目录下的脚本，可能会导致规则文件损坏。**

---

## 📂 目录结构

- **[generate_game_cdn.py](generate_game_cdn.py)**: 自动从 v2fly/domain-list-community 上游下载并生成 `Game_Download_CDN.list` 规则文件。
- **`archived/`**: 存放已废弃或不再使用的历史脚本。[查看详情](archived/README.md)
