# 规则文件

本目录存放本项目维护或保留的 OpenClash 与 Mihomo 规则文件。当前自动生成流程以本目录顶层的 6 个 `.list` 文件和 [`game_rule/`](game_rule/) 中的独立游戏规则为来源，生成 YAML 与 MRS Rule Provider；目录中另有少量人工维护或历史兼容文件。

> [!IMPORTANT]
> 文件位于本目录中，不代表 OpenClash 会自动加载。是否生效取决于配置中的 `rule-providers` 和 `rules` 引用，以及规则顺序和目标策略。

> [!IMPORTANT]
> **本项目的直连规则由维护者与社区用户共同收集。** 如需补充直连域名，可通过 [Rule-Bot](https://t.me/asailor_rulebot)、[Rule-Bot Client](https://github.com/Aethersailor/Rule-Bot-Client)、GitHub Issue 或 Pull Request 提交。

## 自动生成的规则族

| 来源文件 | 内容 | 更新方式 |
| --- | --- | --- |
| [`Custom_Direct.list`](Custom_Direct.list) | 本项目收录的补充直连规则 | 维护者与社区用户共同收集，维护者审核 |
| [`Custom_Proxy.list`](Custom_Proxy.list) | 本项目收录的补充代理规则 | 用户提交与维护者审核 |
| [`Steam_CDN.list`](Steam_CDN.list) | Steam 下载 CDN 补充规则 | 人工维护，并参与游戏下载规则合并 |
| [`Encrypted_DNS.list`](Encrypted_DNS.list) | HaGeZi、DNSCrypt 与 `geosite:category-doh` 汇总规则 | 工作流定期更新 |
| [`Game_Download_CDN.list`](Game_Download_CDN.list) | GeoSite 游戏下载规则与 `Steam_CDN.list` 的合并结果 | 工作流定期更新，保留为兼容入口 |
| [`Tailscale_STUN.list`](Tailscale_STUN.list) | 官方默认 DERP Map 中提供标准 UDP 3478 STUN 服务的公网主机地址 | 每日北京时间 04:17 或手动更新 |

`py/generate_rules.py` 根据规则类型生成下列文件：

| 文件名形式 | `behavior` | 内容 |
| --- | --- | --- |
| `*_Domain.yaml` | `domain` | 纯域名规则 |
| `*_IP.yaml` | `ipcidr` | 纯 IPv4 和 IPv6 CIDR 规则 |
| `*_Classical.yaml` | `classical` | 域名、IP 和端口等 Classical 规则 |
| `*_Classical_IP.yaml` | `classical` | IP 与端口规则 |
| `*_Classical_Port.yaml` | `classical` | 纯端口规则；当前仅为 `Custom_Direct` 生成 |
| `*_Domain.mrs` | `domain` | Domain MRS 规则 |
| `*_IP.mrs` | `ipcidr` | IP-CIDR MRS 规则 |

MRS 当前只用于 `domain` 和 `ipcidr` Rule Provider。Classical 与端口规则继续使用 YAML。预留 Provider 暂时没有规则时，YAML 使用 `payload: []`；生成器保留已有的空 MRS 占位文件，待后续加入规则后再重建。

`Tailscale_STUN` 仅生成 [`Tailscale_STUN_IP.yaml`](Tailscale_STUN_IP.yaml) 和 [`Tailscale_STUN_IP.mrs`](Tailscale_STUN_IP.mrs)，`behavior` 为 `ipcidr`。IPv4 使用 `/32`，IPv6 使用 `/128`，不扩大为上级网段。上游 `STUNPort` 缺省或为 `0` 时按 `3478` 处理；禁用 STUN 或使用其他端口的节点不收录。只提取官方图中明确给出的 IP，不额外通过 DNS 扩充地址。此规则集不包含自建 DERP 或自定义 Peer Relay 地址。

此规则集仅提供地址，不指定直连策略或协议、端口条件，也不会自动加入现有模板。使用方应将地址匹配与 `NETWORK,UDP`、`DST-PORT,3478` 组合；直接将整个地址集合设为直连会同时影响这些地址的其他端口。上游下载、解析或地址校验失败时保留原文件，内容未变化时不生成更新提交。

## 其他文件

| 文件 | 状态 | 说明 |
| --- | --- | --- |
| [`Custom_Port_Direct.yaml`](Custom_Port_Direct.yaml) | 使用中 | 定义 80、443 以外的目标端口范围；当前配置将其交给「非标端口」策略组，不由 `.list` 生成 |
| [`Lan.list`](Lan.list) | 独立保留 | LAN 规则集合；当前主配置未直接引用 |
| [`IPTVMainland_Domain.list`](IPTVMainland_Domain.list) | 独立保留 | IPTV 域名历史列表；当前没有自动更新流程，主配置未直接引用 |
| [`Talkatone.list`](Talkatone.list) | 历史兼容 | 已停止更新；当前 Full 配置改用 `geosite:talkatone` |
| [`archived/`](archived/) | 已归档 | 已停止维护的旧规则，只用于历史参考 |

独立游戏规则位于 [`game_rule/`](game_rule/)，并由同一个工作流生成对应的 YAML 与 MRS 派生文件。

## 修改与验证

修改自动生成规则族时，只编辑对应的 `.list` 来源文件，不要直接编辑同名 YAML 或 MRS 派生文件。生成与一致性检查由 `py/generate_rules.py` 和仓库工作流完成。

使用规则前应确认：

- Provider 的 `behavior`、`format` 与文件内容一致；
- Provider 已下载并解析成功；
- `rules` 中存在对应的 `RULE-SET` 引用；
- 规则顺序和目标策略符合预期；
- 实际连接能够命中目标规则。
